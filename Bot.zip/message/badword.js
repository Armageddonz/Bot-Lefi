// BAD
exports.kasar = [ "anjing","Anjing","Memek","Asu","Asw","Bangsat","Tolol",
"Goblok","Gblk","Ajg","Kontol","mmk","Bangsat","Gblk","tolol",
"peler","Pler","ajg","asw","asu","Babi","kontol","ngentot","bngst","ngewe"]